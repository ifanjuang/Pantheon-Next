# Governance docs — Pantheon Next

Source of truth for project doctrine, architecture, status and policies.

These files were originally split between the repository root and governance discussions. They are consolidated under `docs/governance/` to keep the root readable and to make the Markdown governance layer explicit.

The active operating model is:

```text
OpenWebUI expose.
Hermes Agent exécute.
Pantheon Next gouverne.
```

The runtime must not treat these documents as decorative notes. They drive development decisions.

---

## Inventory

| File | Role |
|---|---|
| `STATUS.md` | Current project state and implementation status |
| `ROADMAP.md` | Detailed active priorities and trajectory |
| `DEVELOPMENT_PHASES.md` | Phase-based reading of the roadmap without replacing detailed roadmap content |
| `ARCHITECTURE.md` | Technical anatomy after the Hermes-backed pivot |
| `HERMES_EXECUTION_MODEL.md` | Runtime execution boundaries, subagent model, LangGraph policy and approval interrupt doctrine |
| `HERMES_CAPABILITY_MAP.md` | Operational map assigning capabilities to Hermes, OpenWebUI, Pantheon or legacy |
| `GOVERNANCE_METHODS.md` | Standard execution methods for classification, Task Contracts, approvals, Evidence Packs and memory candidates |
| `MEMORY_STORAGE_MODEL.md` | Canonical memory storage, indexing, candidate, evidence and approval model |
| `OPENWEBUI_PLUGIN_POLICY.md` | OpenWebUI Functions, Tools, Pipes, Filters, Actions and plugin safety policy |
| `MODULES.md` | Module and domain definition contract |
| `AGENTS.md` | Abstract agent roster and responsibilities; local agent profile policy lives here and in `ROLE_SIGNAL_PROFILES.md` |
| `REQUEST_ORCHESTRATION.md` | Request classification, METIS framing, AGORA consultation, variants, revision and arbitration doctrine |
| `ROUTING_FOUNDATION.md` | Canonical routing foundation for role/skill/workflow boundaries, Request Briefs, W0-W5 and light role consultation |
| `ROLE_SIGNALS.md` | Structured communication schema for role signals, consultations, handoffs, warnings, vetoes and stop gates |
| `ROLE_SIGNAL_PROFILES.md` | Recipient profile registry, local profile invariants and format reminder rules for IRIS-mediated addressed role signals |
| `DELIVERABLE_OPERATING_MODEL.md` | Governance model for complete deliverables, Deliverable Contracts, milestone gates, section gates, Stop Gates and bounded Night Run |
| `GOVERNANCE_ENHANCEMENT_BACKLOG.md` | Candidate backlog for role/skill/workflow, deliverables, assets, Night Run and evaluation improvements |
| `MEMORY.md` | Canonical memory governance |
| `APPROVALS.md` | Approval criticality policy C0-C5 |
| `TASK_CONTRACTS.md` | Hermes/Pantheon task execution contracts |
| `TASK_CONTRACT_REVISIONS.md` | Addendum for single-role task contracts, workflow revision signals, contract revisions, resume policy and reset-to-baseline |
| `EVIDENCE_PACK.md` | Audit contract for consequential outputs |
| `EPISTEMIC_CONTROL.md` | Claim-level evidence, uncertainty, epistemic payloads and skill epistemic contracts |
| `EPISTEMIC_CONTROL_PROPAGATION.md` | Adoption map for applying epistemic control across existing governance documents |
| `EVALUATION.md` | Evaluation doctrine for measuring skills, workflows, outputs and runtime candidates without granting authority |
| `HERMES_INTEGRATION.md` | Pantheon ↔ Hermes boundary and context export rules |
| `OPENWEBUI_INTEGRATION.md` | OpenWebUI cockpit, Knowledge and validation boundary |
| `OPENWEBUI_DOMAIN_MAPPING.md` | Mapping policy between Pantheon canonical domains and OpenWebUI Knowledge Bases, Workspace Models and operator Skills |
| `MODEL_ROUTING_POLICY.md` | Model selection policy for OpenWebUI presets, Ollama instances, Hermes execution and Pantheon abstract agents |
| `EXTERNAL_TOOLS_POLICY.md` | Governance for external integrations |
| `EXTERNAL_RUNTIME_OPTIONS.md` | Classification of optional runtimes, workflow labs, context engines and graph/workspace tools |
| `EXTERNAL_RUNTIME_REVIEW_TEMPLATE.md` | Template for classifying external runtime, agent, MCP, memory, benchmark and tooling options before adoption |
| `EXTERNAL_RUNTIME_OPTION_REVIEWS_KANWAS_AKS_AGENTRQ_OPENCODE_SIX_HATS.md` | Focused review of Kanwas, AKS Reference Server, AgentRQ, opencode-loop and six-hats-skill options |
| `EXTERNAL_AI_OPTION_REVIEWS.md` | Focused reviews for external AI options, structured-output tools, evaluation tools and agent-execution discipline references |
| `EXTERNAL_HERMES_UI_OPTION_REVIEWS.md` | Focused reviews for Hermes web UIs, dashboards, workspaces, memory providers, search plugins, skill packs, self-evolution tools and ecosystem catalogues |
| `EXTERNAL_ECOSYSTEM_REVIEWS.md` | External repository review register for SwarmKit, leaf, ECC and Hermes memory installer candidates |
| `EXTERNAL_MEMORY_RUNTIME_REVIEWS_OPENCONCHO_HONCHO.md` | Review of OpenConcho and Honcho as external memory runtime options rejected for core memory |
| `EXECUTION_DISCIPLINE.md` | Minimal execution discipline: smallest safe path, single-role before workflow, surgical changes and evidence before assertion |
| `KNOWLEDGE_TAXONOMY.md` | Knowledge vs Memory classification |
| `CODE_AUDIT_POST_PIVOT.md` | Legacy/runtime code classification register |
| `PRE_REFACTOR_ARCHITECTURE_FINDINGS.md` | Read-only audit synthesis of existing code assets to preserve or reclassify before refactor |
| `RUN_GRAPH.md` | Read-only run observation schema and optional Inline Run Stream rules |
| `WORKFLOW_SCHEMA.md` | Canonical workflow/task definition schema |
| `WORKFLOW_ADAPTATION.md` | Adaptive workflow doctrine: session workflows, dependency graphs, role consultation, ZEUS arbitration and reset/candidate rules |
| `SKILL_LIFECYCLE.md` | Skill lifecycle, XP/status and Hermes mapping policy |
| `MEMORY_EVENT_SCHEMA.md` | Memory event and candidate schema before promotion |
| `EXTERNAL_WATCHLIST.md` | External repo / tool watchlist |
| `VERSIONS.md` | Tracking versions of runtimes and models |
| `AI_LOG.md` | Deprecated pointer to `ai_logs/README.md`; retained only to resolve stale references and prevent recreation of the former single-file log |

---

## Root entry points

The following files stay at the repository root:

- `README.md` — product entry point for Pantheon Next.
- `CLAUDE.md` — Claude-specific repository guidance aligned with Pantheon Next.
- `CHANGELOG.md` — release/change history.
- `VERSION` — current version marker.

The AI coordination journal lives in `ai_logs/`.

Reference:

```text
ai_logs/README.md
```

---

## Local agent profiles

Per-agent maintenance metadata may live under:

```text
agents/{ROLE}/role_signal_profile.yaml
```

This is allowed only as a local usage profile.

It does not replace:

```text
docs/governance/ROLE_SIGNALS.md
docs/governance/ROLE_SIGNAL_PROFILES.md
docs/governance/EPISTEMIC_CONTROL.md
```

---

## Governance rules

1. Read `ai_logs/README.md` and recent log entries before intervention.
2. Read `docs/governance/STATUS.md` before structural changes.
3. Read the relevant governance document before modifying code.
4. Do not push directly to `main`.
5. Use a dedicated branch.
6. Add an `ai_logs/YYYY-MM-DD-slug.md` entry after significant intervention.
7. Do not write real private project/client data into the repository.
8. If code contradicts Markdown, Markdown is the source of truth.
9. If code is technically better than Markdown, update Markdown first before generalizing the code path.
10. Prefer the smallest safe path: single-role path before workflow, workflow template before new abstraction.

---

## Forbidden drift

Pantheon Next must not silently recreate:

- autonomous Pantheon runtime;
- Execution Engine;
- Agent Runtime;
- Tool Runtime;
- LLM Provider Router;
- scheduler;
- LangGraph central orchestrator;
- memory auto-promotion;
- self-evolution auto-merge;
- uncontrolled plugin installation.

Hermes Agent executes. Pantheon Next governs. OpenWebUI exposes.
