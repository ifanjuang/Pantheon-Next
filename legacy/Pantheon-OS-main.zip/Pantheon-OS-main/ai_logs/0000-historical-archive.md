# AI LOG — Archive historique

Entrées historiques préservées telles qu'elles figuraient dans
`docs/governance/AI_LOG.md` (ancien fichier unique) avant l'unification
sur le format `ai_logs/YYYY-MM-DD-slug.md`.

Les chemins mentionnés dans ces entrées (`STATUS.md`, `MODULES.md`, etc.)
faisaient référence à la racine du dépôt à l'époque ; ils correspondent
aujourd'hui à `docs/governance/STATUS.md`, `docs/governance/MODULES.md`,
etc.

---

## Log

### 2026-04-26 — ChatGPT

Branche : `feature/approval-gate-activation`

Objectif : renforcer les fondations de Pantheon OS avant activation des modules avancés.

Modifications :

- Ajout `CODE_AUDIT.md`.
- Ajout `ManifestLoader` runtime tolérant.
- Ajout contrat manifest progressif `ComponentManifest`.
- Branchement du contrat manifest dans `ModuleRegistry` et `ManifestLoader`.
- Ajout contrats `TaskDefinition` et `WorkflowDefinition`.
- Ajout loader `workflow.yaml` / `tasks.yaml`.
- Branchement du loader workflow au startup dans `platform/api/main.py`.
- Ajout workflow réel `modules/workflows/document_analysis/`.
- Ajout endpoint debug `/debug/runtime-registry`.
- Ajout module `approvals` avec modèle, schémas, service, router.
- Ajout migration `approval_requests`.
- Enregistrement `approvals` dans `modules.yaml` mais avec `enabled: false`.
- Ajout tests contractuels manifests, tasks, workflows, approval.
- Ajout Installer UI autonome NAS + Ollama LAN.
- Ajout script Windows pour préparer Ollama.
- Ajout gouvernance versions : `VERSION`, `CHANGELOG.md`, `VERSIONS.md`, `EXTERNAL_WATCHLIST.md`.
- Ajout scripts update partiels.
- Ajout `AI_LOG.md` comme journal simple de coordination IA.

Fichiers critiques touchés :

- `STATUS.md`
- `modules.yaml`
- `platform/api/main.py`
- `platform/api/core/health.py`
- `platform/api/core/registry.py`
- `platform/api/core/registries/loader.py`
- `platform/api/core/registries/workflows.py`
- `platform/api/core/contracts/manifest.py`
- `platform/api/core/contracts/tasks.py`
- `platform/api/apps/approvals/*`
- `alembic/versions/20260426_0001_add_approval_requests.py`

Tests lancés :

- Non exécutés dans cette session.

Points à vérifier :

- Migration Approval Gate : `down_revision = None` à vérifier avec `alembic heads`.
- Tests non exécutés.
- Installer UI non testée sur NAS.
- Module `approvals` toujours désactivé.
- Les workflows sont chargés et exposés, mais pas encore exécutés par un moteur runtime.
- `OpenWebUI` utilise encore un tag Docker potentiellement instable si `main` est conservé.

Prochaine action recommandée :

1. Lancer l’Installer UI sur NAS : `bash scripts/install/ui/launch_installer.sh`.
2. Vérifier Docker, Ollama, `.env`, containers, migrations, tests, `/health`, `/debug/runtime-registry`.
3. Vérifier Alembic avec `alembic heads`.
4. Corriger `down_revision` si nécessaire.
5. Exécuter les tests ciblés.
6. Activer `approvals` seulement après validation migration + tests.

---

### 2026-04-26 — ChatGPT

Branche : `feature/approval-gate-activation`

Objectif : ajouter `mage0535/hermes-memory-installer` à la roadmap comme source externe mémoire / installation, sans intégration code.

Modifications :

- Mise à jour de `ROADMAP.md` section `Memory Roadmap`.
- Ajout de `mage0535/hermes-memory-installer` dans `External Inspiration Map` sous `À intégrer plus tard`.
- Décision documentaire : retenir l’idée d’installation mémoire locale, injection mémoire, auto-mount de skills et archivage comme piste ultérieure.
- Décision de rejet : ne pas reprendre SQLite FTS5 comme source de vérité principale, ni installation intrusive non auditée, ni promotion mémoire non validée.

Fichiers critiques touchés :

- `ROADMAP.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés. Modification documentaire uniquement.

Points à vérifier :

- Le dépôt externe n’a pas encore été audité en profondeur fichier par fichier.
- L’idée doit rester en veille jusqu’à stabilisation du modèle mémoire Pantheon, Approval Gate et PolicyGate.

Prochaine action recommandée :

1. Ne pas intégrer de code depuis `hermes-memory-installer` maintenant.
2. Continuer d’abord Lot A : Installer UI, Alembic, tests.
3. Revenir à cette piste pendant le chantier mémoire multi-couches.

---

### 2026-04-26 — ChatGPT

Branche : `feature/approval-gate-activation`

Objectif : consolider tous les repos externes déjà évoqués dans `EXTERNAL_WATCHLIST.md`.

Modifications :

- Ajout ou clarification des entrées : `hermes-memory-installer`, `RAG-Evaluation`, `browser-harness`, `Langflow`, `Dify`, `n8n`, `OmniTools`, `StartOS`, `CommonMark`, `agents-towards-production`.
- Ajout d’une synthèse par chantier Pantheon : governance documentaire, runtime contracts, approval, memory, RAG quality, self-hosting, visual lab, automation périphérique, local tools, browser tool.
- Ajout de règles d’usage : pas de second runtime de vérité, pas d’import massif d’agents, pas de Browser Tool avant Approval/Policy/Observability, pas de mise à jour automatique sans consentement.

Fichiers critiques touchés :

- `EXTERNAL_WATCHLIST.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés. Modification documentaire uniquement.

Points à vérifier :

- Certains dépôts sont classés après analyse conceptuelle, sans audit fichier par fichier.
- Aucun code externe n’a été intégré.
- Les idées restent subordonnées aux Markdown de référence et au modèle Pantheon.

Prochaine action recommandée :

1. Continuer Lot A : Installer UI, Alembic, tests.
2. Ne pas ouvrir de nouveau chantier externe avant stabilisation.
3. Reprendre ensuite Approval Gate complet, puis mémoire et RAG Evaluation.

---

### 2026-04-26 — ChatGPT

Branche : `feature/approval-gate-activation`

Objectif : acter le pivot documentaire Hermes-backed / Domain Operating Layer.

Modifications :

- Réécriture de `README.md` : Pantheon devient Domain Operating Layer ; Hermes Agent devient runtime agentique ; OpenWebUI devient interface + knowledge documentaire.
- Réécriture de `ARCHITECTURE.md` : architecture en trois couches, responsabilités OpenWebUI / Hermes Agent / Pantheon OS, memory model, approval discipline, Hermes Integration Layer.
- Réécriture de `AGENTS.md` : agents abstraits et neutres métier ; spécialisation uniquement par domain overlays, workflows, skills et knowledge policies.
- Réécriture de `MODULES.md` : modules recentrés sur contrats, domain overlays, skills, workflows, memory, knowledge, hermes integration et operations.
- Réécriture de `ROADMAP.md` : priorité à l’audit post-pivot, Hermes Lab isolé, skills métier, OpenWebUI Knowledge Strategy, mémoire validée et Hermes Integration Layer.
- Mise à jour de `STATUS.md` : pivot documentaire confirmé ; code existant marqué comme partiellement obsolète et à réauditer.
- Aucune modification de code.

Fichiers critiques touchés :

- `README.md`
- `ARCHITECTURE.md`
- `AGENTS.md`
- `MODULES.md`
- `ROADMAP.md`
- `STATUS.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés. Modification documentaire uniquement.

Points à vérifier :

- Le code existant reste majoritairement orienté ancienne trajectoire autonome : FastAPI, registries, workflow loader, approval API, Installer UI.
- Ces éléments doivent être audités avant conservation, réorientation, archivage ou suppression.
- Hermes Agent n’est pas installé. L’installation éventuelle doit se faire en Hermes Lab isolé, sans accès Docker socket, volumes Pantheon ou secrets.
- OpenWebUI Knowledge Strategy reste à créer.
- Les dossiers contractuels `agents/`, `domains/`, `skills/`, `workflows/`, `memory/`, `knowledge/`, `hermes/context/`, `operations/` restent à créer.

Prochaine action recommandée :

1. Faire l’audit post-pivot code/docs.
2. Créer le squelette contractuel Pantheon Domain Layer.
3. Préparer `hermes/context/pantheon_context.md`, `agents_context.md` et `rules_context.md`.
4. Définir la stratégie OpenWebUI Knowledge.
5. Préparer un plan d’installation Hermes Lab isolé.

---

### 2026-04-26 — ChatGPT

Branche : `work/chatgpt/hermes-code-rewrite`

Objectif : créer une première couche code alignée avec le pivot Hermes-backed, sans supprimer brutalement l’ancien runtime autonome.

Modifications :

- Création de la branche dédiée `work/chatgpt/hermes-code-rewrite`.
- Ajout du package `platform/api/pantheon_domain/`.
- Ajout de contrats Pydantic : agents, skills, workflows, memory stores, knowledge collections, legacy components et approval classification.
- Ajout d’un repository statique `DomainLayerRepository` représentant la doctrine Pantheon côté code.
- Ajout des routes FastAPI `/domain/*` : snapshot, agents, skills, workflows, memory, knowledge, legacy, approval classifier.
- Remplacement de `platform/api/main.py` par une entrée FastAPI simple Domain Layer.
- Ajout des tests ciblés `tests/test_domain_layer_api.py`.
- Mise à jour de `STATUS.md` pour indiquer que la première couche code existe, mais que les tests n’ont pas été exécutés ici.
- Aucun code externe intégré.
- Ancien runtime conservé dans le dépôt et marqué legacy à auditer.

Fichiers critiques touchés :

- `platform/api/main.py`
- `platform/api/pantheon_domain/__init__.py`
- `platform/api/pantheon_domain/contracts.py`
- `platform/api/pantheon_domain/repository.py`
- `platform/api/pantheon_domain/router.py`
- `tests/test_domain_layer_api.py`
- `STATUS.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés dans cette session.
- Tests ajoutés mais à lancer localement : `pytest tests/test_domain_layer_api.py`.

Points à vérifier :

- Compatibilité imports dans l’environnement local.
- Dépendances FastAPI / Pydantic / pytest / httpx.
- Ancien code legacy potentiellement cassé si `pytest` complet est lancé sans adaptation.
- Docker/NAS non testé.
- L’API ne charge plus automatiquement l’ancien runtime dynamique.
- Les endpoints `/debug/runtime-registry` et anciens modules ne sont plus le chemin principal.

Prochaine action recommandée :

1. Lancer `pytest tests/test_domain_layer_api.py`.
2. Démarrer l’API localement et vérifier `/health` et `/domain/snapshot`.
3. Créer les dossiers contractuels Markdown : `agents/`, `domains/`, `skills/`, `workflows/`, `memory/`, `knowledge/`, `hermes/context/`, `operations/`.
4. Auditer le legacy avant toute suppression.
5. Préparer Hermes Lab isolé seulement après validation de la couche Domain Layer.

---

### 2026-04-28 — ChatGPT

Branche : `work/chatgpt/hermes-docs-architecture-fr`

Objectif : formaliser le système de progression des skills Pantheon avec XP, niveaux, anti-farming et feedback utilisateur non intrusif.

Modifications :

- Mise à jour de `hermes/skill_policy.md`.
- Ajout des états de lifecycle : `candidate`, `active`, `probation`, `quarantine`, `archived`, `rejected`.
- Ajout d’un modèle XP qualitatif basé sur les améliorations validées, pas sur le volume d’usage.
- Ajout d’une table XP : feedback utile, clarification, correction de blocage, checklist, garde-fou, extraction de workflow, upgrade majeur.
- Ajout de règles anti-farming : pas de XP pour volume brut, doublons, auto-évaluation ou cosmétique.
- Ajout des niveaux : Candidate, Usable, Stable, Reliable, Expert, Core.
- Ajout des conditions de level-up : XP validée, absence de critique ouverte, exemples/tests/checklists à jour, privacy check, rollback, validation humaine.
- Ajout d’une politique de feedback non intrusif : demander seulement après réponse substantielle, méthode réutilisable, correction de blocage ou proposition de workflow/skill.
- Ajout du modèle `lifecycle` dans `manifest.yaml`.

Fichiers critiques touchés :

- `hermes/skill_policy.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés. Modification documentaire uniquement.

Points à vérifier :

- Reporter les règles XP/levels dans `MODULES.md` lors de l’alignement.
- Prévoir les champs `lifecycle` dans les futurs `manifest.yaml`.
- Ne pas transformer le feedback utilisateur en demande systématique après chaque réponse.
- Garder les XP comme `pending_xp` tant qu’une review n’a pas validé l’amélioration.

Prochaine action recommandée :

1. Aligner `MODULES.md` sur lifecycle + XP.
2. Créer les premières skills `domains/general` avec `manifest.yaml` incluant `lifecycle`.
3. Prévoir un workflow `skill_review.yaml` avant tout level-up.

---

### 2026-04-29 — ChatGPT

Branche : `work/chatgpt/hermes-docs-architecture-fr`

Objectif : poser le P0 de l’interaction OpenWebUI / Hermes / Pantheon et ajouter la résolution de contexte projet.

Modifications :

- Mise à jour de `STATUS.md` avec `OpenWebUI / Hermes / Pantheon interaction layer — planned`.
- Mise à jour de `MODULES.md` pour ajouter les modules planifiés : Consultation, Evidence Pack, Run Graph, Runtime Context Pack, Knowledge Selection.
- Ajout du package `platform/api/pantheon_runtime/`.
- Ajout d’un endpoint statique read-only `GET /runtime/context-pack`.
- Branchement du router runtime dans `platform/api/main.py`.
- Ajout de la skill candidate `domains/general/skills/project_context_resolution/`.
- Ajout de règles de résolution de contexte projet : alias, fautes de frappe, indices partiels, commune, rue, client, sujet, mémoire session/projet, Knowledge Registry, Notion read-only éventuel.
- Ajout de la règle inverse : ne pas forcer le contexte projet si la question est générale ou répondable sans contexte spécifique.
- Ajout de la politique Notion : lecture seule par défaut, écriture uniquement après affichage des champs à modifier et validation explicite.
- Ajout du template local Hermes `hermes/templates/pantheon-os/` avec `SKILL.md`, exemple d’audit repo et helper read-only `pantheon_context_pack.py`.

Fichiers critiques touchés :

- `STATUS.md`
- `MODULES.md`
- `AI_LOG.md`
- `platform/api/main.py`
- `platform/api/pantheon_runtime/__init__.py`
- `platform/api/pantheon_runtime/router.py`
- `domains/general/skills/project_context_resolution/SKILL.md`
- `domains/general/skills/project_context_resolution/manifest.yaml`
- `domains/general/skills/project_context_resolution/examples.md`
- `domains/general/skills/project_context_resolution/tests.md`
- `domains/general/skills/project_context_resolution/UPDATES.md`
- `hermes/templates/pantheon-os/SKILL.md`
- `hermes/templates/pantheon-os/examples/audit_repo.md`
- `hermes/templates/pantheon-os/scripts/pantheon_context_pack.py`

Tests lancés :

- Non exécutés dans cette session.

Points à vérifier :

- Lancer les tests existants ciblés après checkout local.
- Vérifier le démarrage FastAPI et les routes `/health`, `/domain/snapshot`, `/runtime/context-pack`.
- Le Context Pack est statique : il oriente Hermes mais ne remplace pas les Markdown de référence.
- Le template Hermes `pantheon-os` n’est pas installé localement ; il doit être copié vers `~/.hermes/skills/pantheon-os/` avant usage.
- La connexion Notion n’est pas implémentée ; seule la politique de lecture/écriture candidate est documentée.
- Le template Evidence Pack exécutable ou YAML n’a pas été ajouté : deux tentatives de création ont été bloquées par le contrôle de sécurité de l’outil GitHub. La structure reste documentée dans `MODULES.md` et `hermes/templates/pantheon-os/SKILL.md`.
- Le legacy autonome reste à auditer avant conservation, réorientation ou suppression.

Prochaine action recommandée :

1. Lancer `pytest tests/test_domain_layer_api.py` et vérifier l’import du nouveau router runtime.
2. Démarrer l’API localement et tester `GET /runtime/context-pack`.
3. Créer `knowledge/registry.yaml` et la skill candidate `knowledge_selection`.
4. Définir un mapping Notion read-only avant toute écriture possible.
5. Créer une spécification OpenWebUI Router Pipe + Actions.

---

### 2026-04-29 — ChatGPT

Branche : `work/chatgpt/hermes-docs-architecture-fr`

Objectif : intégrer le P0 documentaire post-pivot inspiré de Hades 2.0 sans recréer de runtime autonome ni de dashboard lourd.

Modifications :

- Ajout de `APPROVALS.md` avec niveaux C0 à C5, mapping actions/outils et règles Hermes/OpenWebUI.
- Ajout de `TASK_CONTRACTS.md` avec le schéma minimal de tâche exécutable et les premiers contrats : `repo_consistency_audit`, `quote_vs_cctp_review`, `client_message_review`, `memory_promotion_review`, `skill_candidate_review`, `legacy_component_audit`.
- Ajout de `EVIDENCE_PACK.md` avec le paquet de preuves obligatoire pour audits, analyses devis/CCTP, modifications Markdown, skills, mémoire, communications client et legacy audit.
- Ajout de `HERMES_INTEGRATION.md` pour clarifier que Hermes exécute, Pantheon gouverne/canonise et OpenWebUI expose l’interface/knowledge.
- Ajout de `KNOWLEDGE_TAXONOMY.md` pour séparer OpenWebUI Knowledge de la mémoire Pantheon, avec couches, niveaux R0-R5 et collections initiales `architecture_fr`.
- Mise à jour de `STATUS.md` pour inscrire les nouveaux contrats P0 comme documents de référence.
- Mise à jour de `ROADMAP.md` pour remplacer les chemins legacy par `domains/general`, `domains/architecture_fr`, `domains/software` et repousser P1/P2/P3.
- Mise à jour de `MODULES.md` pour intégrer task contracts, approvals et Evidence Pack comme modules de gouvernance.
- Mise à jour de `AGENTS.md` pour relier les agents aux niveaux C0-C5, task contracts, Evidence Packs, mémoire et limites Hermes.
- Mise à jour de `MEMORY.md` pour supprimer les blocs cassés et imposer promotion C3 + Evidence Pack.
- Mise à jour de `ARCHITECTURE.md` pour intégrer `APPROVALS.md`, `TASK_CONTRACTS.md`, `EVIDENCE_PACK.md`, `HERMES_INTEGRATION.md` et `KNOWLEDGE_TAXONOMY.md` dans l’anatomie technique.
- Aucun code runtime modifié pendant cette intervention.

Fichiers critiques touchés :

- `STATUS.md`
- `ROADMAP.md`
- `ARCHITECTURE.md`
- `AGENTS.md`
- `MODULES.md`
- `MEMORY.md`
- `AI_LOG.md`

Fichiers ajoutés :

- `APPROVALS.md`
- `TASK_CONTRACTS.md`
- `EVIDENCE_PACK.md`
- `HERMES_INTEGRATION.md`
- `KNOWLEDGE_TAXONOMY.md`

Tests lancés :

- Non exécutés. Intervention documentaire uniquement.

Points à vérifier :

- Relancer une recherche globale des chemins legacy : `domains/architecture`, `skills/architecture`, `workflows/architecture`, `memory/agency`.
- Vérifier localement que les liens et références Markdown restent cohérents.
- Lancer les tests API existants si le code est vérifié dans la même branche.
- Les P1/P2/P3 n’ont pas été implémentés : pas de quality gates, pas de workflows, pas de domain package complet, pas d’extension API additionnelle.
- Les nouveaux documents définissent la gouvernance ; ils ne constituent pas une exécution autonome.

Prochaine action recommandée :

1. Créer `knowledge/registry.yaml`.
2. Créer `domains/general/skills/knowledge_selection/`.
3. Créer les exports `hermes/context/*.md`.
4. Créer les fichiers de règles des domaines `general`, `architecture_fr`, `software`.
5. Lancer les vérifications locales : Markdown links, `/health`, `/domain/snapshot`, `/runtime/context-pack`, puis tests ciblés.

---

### 2026-04-29 — ChatGPT

Branche : `work/chatgpt/hermes-docs-architecture-fr`

Objectif : mettre à jour `ROADMAP.md` avec la roadmap corrigée d’intégration des outils externes, PDF, OpenWebUI extensions, skills, mémoire structurée et self-evolution encadrée.

Modifications :

- Remplacement de `ROADMAP.md` par une version alignée sur la doctrine actuelle.
- Ajout du principe : Pantheon définit/gouverne, Hermes exécute, OpenWebUI expose, Stirling traite les PDF, les plugins restent sous allowlist.
- Ajout de `EXTERNAL_TOOLS_POLICY.md` comme prochaine priorité documentaire.
- Ajout du séquençage strict : compléter `APPROVALS.md`, `EVIDENCE_PACK.md`, `TASK_CONTRACTS.md` avec outils externes, fallback et remediation.
- Ajout de la stratégie Stirling-PDF comme premier outil externe P1.
- Ajout des chemins corrigés pour les skills/workflows : `domains/general/...`, `domains/architecture_fr/...`, `domains/software/...`.
- Ajout des blocs OpenWebUI extensions, Skill Resolver, conventions, Skill Lifecycle, Memory Event Schema, Self-Evolution, Workflow Schema, Hermes allowlists et Remediation Candidate Lane.
- Suppression des anciens chemins actifs `domains/architecture`, `skills/generic`, `workflows/generic`, `memory/agency` hors mention legacy explicite.
- Aucun code runtime modifié.

Fichiers critiques touchés :

- `ROADMAP.md`
- `AI_LOG.md`

Tests lancés :

- Non exécutés. Intervention documentaire uniquement.

Points à vérifier :

- Rechercher les anciens chemins dans `ROADMAP.md` et le dépôt : `domains/architecture`, `skills/generic`, `workflows/generic`, `memory/agency`.
- Vérifier que `STATUS.md` reste cohérent avec la nouvelle priorité `EXTERNAL_TOOLS_POLICY.md`.
- Vérifier que `APPROVALS.md`, `TASK_CONTRACTS.md`, `EVIDENCE_PACK.md` seront complétés avant toute intégration Stirling/OpenWebUI/plugin.

Prochaine action recommandée :

1. Créer `EXTERNAL_TOOLS_POLICY.md`.
2. Compléter `APPROVALS.md` avec outils externes, fallback et remediation.
3. Compléter `EVIDENCE_PACK.md` avec extended schema, fallback et remediation.
4. Compléter `TASK_CONTRACTS.md` avec contrats PDF, `fallback_policy` et `remediation_policy`.
5. Créer `operations/stirling_pdf.md` seulement après le verrouillage documentaire externe.

---

### YYYY-MM-DD — Claude

Branche :

Objectif :

Modifications :

Fichiers critiques touchés :

Tests lancés :

Points à vérifier :

Prochaine action recommandée :
