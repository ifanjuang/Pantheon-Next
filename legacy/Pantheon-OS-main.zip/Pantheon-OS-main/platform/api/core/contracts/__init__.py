"""Core runtime contracts."""
