"""Approval Gate API module."""
