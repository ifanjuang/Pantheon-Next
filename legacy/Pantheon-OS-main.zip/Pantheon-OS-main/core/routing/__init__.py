"""Intent → workflow routing."""
